from django.shortcuts import render

import joblib
from  django.http import  HttpResponse
from django.shortcuts import render


def home(request):

    return  render(request,"home.html")




def result(request):
    y_pred = joblib.load('Models/knn.sav')

    lis = []
    lis.append(request.GET['age'])
    lis.append(request.GET['sex'])
    lis.append(request.GET['cp'])
    lis.append(request.GET['trestbps'])
    lis.append(request.GET['chol'])
    lis.append(request.GET['fbs'])
    lis.append(request.GET['restecg'])
    lis.append(request.GET['exang'])
    lis.append(request.GET['oldpeak'])
    lis.append(request.GET['slope'])
    lis.append(request.GET['ca'])
    lis.append(request.GET['thal'])

    print(lis)

    knn=y_pred.predict([lis])



    if knn == 1:
            knn = "You Have Heart Problems"
            preventions = "Avoid freid foots and sugar ... Exercise Daily"
            msg = "Contact Doctor Immediately"

    else:
            knn = "Congratulations !! You Don't Have Any Heart Problems"
            preventions = ""
            msg = ""









    return  render(request,"result.html",{'knn':knn, 'preventions':preventions,'msg':msg})

